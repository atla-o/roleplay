Roleplay for Linux (aarch64)
Godot 4.7.2. The terrain is inside this build. Nothing is downloaded on first run.

Run
  ./run.sh
If the window stays black (Asahi Honeykrisp, or a machine without Vulkan):
  ./run-compat.sh
That forces the OpenGL 3 Compatibility renderer. Logs go to roleplay.log
next to this file.

Controls
  Robot: W throttle, S reverse, A and D steer.
  Blade: Q raises, E lowers. Z and C tilt the blade.
  Mouse or the right stick orbits the chase camera.
  Human: WASD, Shift to run, Space to jump.
  Settings is the button at the bottom left. It switches Robot and Human
  and teleports to named places (basin Slope, Ridge, Low ground, Lake;
  island Forest, Shore, Heights). Esc closes it.

Benchmark
  ./run.sh --bench
  Prints avg_fps and low1_fps after about 14 seconds, then quits.
