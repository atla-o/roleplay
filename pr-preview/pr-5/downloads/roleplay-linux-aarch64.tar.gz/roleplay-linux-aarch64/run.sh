#!/bin/sh
# Launch Roleplay. Tries Vulkan Forward+. If that fails, OpenGL Compatibility.
set -u
cd "$(dirname "$0")"
BIN="./roleplay.arm64"
LOG="./roleplay.log"
launch_compat() {
  echo "Starting with OpenGL Compatibility (run-compat.sh does this directly)." | tee -a "$LOG"
  exec "$BIN" --rendering-driver opengl3 --rendering-method gl_compatibility --log-file "$LOG" "$@"
}
if [ "${ROLEPLAY_GL:-}" = "1" ]; then
  launch_compat "$@"
fi
echo "Starting Forward+. A black window means Vulkan failed: run ./run-compat.sh" | tee -a "$LOG"
"$BIN" --rendering-driver vulkan --rendering-method forward_plus --log-file "$LOG" "$@" >>"$LOG" 2>&1 &
pid=$!
i=0
while [ "$i" -lt 12 ]; do
  if ! kill -0 "$pid" 2>/dev/null; then
    wait "$pid" || true
    echo "Forward+ exited. Retrying with OpenGL Compatibility." | tee -a "$LOG"
    launch_compat "$@"
  fi
  if grep -E -q "switching to OpenGL|Failed to initialize Vulkan|VK_KHR_surface|Vulkan initialization failed|Can't create a Vulkan" "$LOG" 2>/dev/null; then
    kill "$pid" 2>/dev/null || true
    wait "$pid" 2>/dev/null || true
    echo "Vulkan is not usable here. Retrying with OpenGL Compatibility." | tee -a "$LOG"
    launch_compat "$@"
  fi
  i=$((i + 1))
  sleep 0.5
done
wait "$pid"
