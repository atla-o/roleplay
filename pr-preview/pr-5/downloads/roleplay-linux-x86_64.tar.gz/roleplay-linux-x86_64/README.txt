Roleplay for Linux (x86_64)
Godot 4.7.2. The terrain is inside this build. Nothing is downloaded on first run.
The window class is roleplay. The title is Roleplay.

Install for this user
  ./install.sh
That copies the game to ~/.local/share/roleplay, puts a launcher at
~/.local/bin/roleplay (any file already there is saved as roleplay.bak),
and installs the desktop entry and icons. Remove it with ./uninstall.sh.

Run without installing
  ./run.sh
If the window stays black (Asahi Honeykrisp, or a machine without Vulkan):
  ./run-compat.sh
The installed launcher uses the same Vulkan-then-OpenGL fallback.
Logs go to roleplay.log next to the game.

Controls
  You start in the dozer on Northern 1 — Canada. W drives, and the blade
  is already down, so the ground moves.
  S reverse, A and D steer. Q raises the blade, E lowers it.
  The screen stays clear. Esc opens Settings and Esc closes it.
  Settings switches Robot and Human, teleports to Northern 1 — Canada,
  Northern 2 — Europe, or Northern 3 — Russia, and has Resume and Quit.

Benchmark
  ./run.sh --bench
  Prints avg_fps and low1_fps after about 14 seconds, then quits.
