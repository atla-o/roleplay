#!/bin/sh
# Asahi and other machines where Vulkan Forward+ stays black.
set -u
cd "$(dirname "$0")"
LOG="./roleplay.log"
echo "OpenGL Compatibility. Log: $LOG"
exec "./roleplay.x86_64" --rendering-driver opengl3 --rendering-method gl_compatibility --log-file "$LOG" "$@"
